class StaticPagesController < ApplicationController
  def home
  end

  def contactUs
  end

  def aboutUs
  end
end
