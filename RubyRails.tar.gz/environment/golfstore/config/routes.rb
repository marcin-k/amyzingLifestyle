Rails.application.routes.draw do
  resources :orders do resources:orderitems
end

  devise_for :users do resources:orders 
end
  
  get 'cart/index'
  resources :items
  root 'static_pages#home'
  get '/help' => 'static_pages#help'
  get '/about' => 'static_pages#about'
  get '/cart' => 'cart#index'
  get '/cart/clear' => 'cart#clear'
  get '/cart/:id' => 'cart#add'
  get '/cart/remove/:id' => 'cart#remove'
  get '/checkout' => 'cart#createOrder'
  get '/payment' => 'orders#pay'
  get '/shipped/:id' => 'orders#shipped'
  
  post '/search' => 'items#search'
  
  # syntax is controller#method
  
  # For details on the DSL available within this file, see http://guides.rubyonrails.org/routing.html
end
