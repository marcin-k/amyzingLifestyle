class Orderitem < ApplicationRecord
  belongs_to :order
end
