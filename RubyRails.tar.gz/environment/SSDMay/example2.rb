num1 = gets()
num2 = 9
if (num1.to_i>num2) #convert to integer, to_s is to string
    puts "hello"
else
    puts "wrong"
end #all ifs need an end