10.times do

puts "Enter a number"
guess=gets.to_i()

num=rand(1..100)
counter=0

if (guess=num)
    puts "you guessed correctly"
elseif (guess>num)
    puts "your guess was too high, please guess again"
    counter=counter+1
    puts "You have #{10-counter} guesses left"
else
    puts "your guess was too low, please guess again"
    counter=counter+1
    puts "You have #{10-counter} guesses left"
end

end


puts "number was #{num}"