puts "Kevin loves Amy"
#comments with hash
#up arrow in directory repeats what was just done

puts "Amy is happy \nKevin is getting some" #\n is new line

2.times do puts "What is your name?"
name = gets()  #gets is user input default stringer
puts "Hi #{name}"  # a hashtag and curly braces concatenates strings and variables
end



