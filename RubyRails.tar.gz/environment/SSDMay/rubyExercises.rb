puts "What is your name?"
name = gets()  #gets is user input default stringer
puts "Hi #{name}"  # a hashtag and curly braces concatenates strings and variables

puts "Enter two numbers"
num1=gets.to_i()
num2=gets.to_i()
puts (num1)*(num2)
