class Mammal
    def breathe
        puts "inhales and exhales"
    end
end

class Cat<Mammal
    def speak
        puts "Meow"
    end
end

class Lion<Mammal
    def speak
        puts "Roar"
    end
end

class Turkey<Lion
    def fly
        puts "I'm flying"
    end
end

dodger=Cat.new
dodger.breathe
dodger.speak
lion1=Lion.new
lion1.breathe
lion1.speak
turkey=Turkey.new
turkey.speak
turkey.fly
turkey.breathe
    